# Copyright (c) Facebook, Inc. and its affiliates.
# All rights reserved.
# This source code is licensed under the license found in the
# LICENSE file in the root directory of this source tree.
# Earlier versions of this file were written by Zhengdao Chen, used with permission.
from torch.optim.lr_scheduler import ReduceLROnPlateau
import numpy as np
import torch
import torch.nn as nn
from torch.autograd import grad
from tqdm import tqdm


def leapfrog(p_0, q_0, Func, T, dt, volatile=True, is_Hamilt=False, device='cpu', use_tqdm=False):
    trajectories = torch.empty((T, p_0.shape[0], 2 * p_0.shape[1]), requires_grad=False).to(device)

    p = p_0
    q = q_0
    p.requires_grad_()
    q.requires_grad_()

    if use_tqdm:
        range_of_for_loop = tqdm(range(T))
    else:
        range_of_for_loop = range(T)

    dim = p_0.shape[1]
    time_drvt = Func(torch.cat((p, q), 1))  # deltax x
    dpdt = time_drvt[:, :dim]

    for i in range_of_for_loop:
        p_half = p + dpdt * (dt / 2)

        if volatile:
            trajectories[i, :, :dim] = p.detach()
            trajectories[i, :, dim:] = q.detach()
        else:
            trajectories[i, :, :dim] = p
            trajectories[i, :, dim:] = q

        time_drvt = Func(torch.cat((p_half, q), 1))
        dqdt = time_drvt[:, dim:]

        q_next = q + dqdt * dt

        time_drvt = Func(torch.cat((p_half, q_next), 1))
        dpdt = time_drvt[:, :dim]

        p_next = p_half + dpdt * (dt / 2)

        p = p_next
        q = q_next

    return trajectories


def euler(p_0, q_0, Func, T, dt, volatile=True, is_Hamilt=False, device='cpu', use_tqdm=False):
    trajectories = torch.empty((T, p_0.shape[0], 2 * p_0.shape[1]), requires_grad=False).to(device)

    p = p_0
    q = q_0
    p.requires_grad_()
    q.requires_grad_()

    if use_tqdm:
        range_of_for_loop = tqdm(range(T))
    else:
        range_of_for_loop = range(T)

    dim = p_0.shape[1]

    for i in range_of_for_loop:

        if volatile:
            trajectories[i, :, :dim] = p.detach()
            trajectories[i, :, dim:] = q.detach()
        else:
            trajectories[i, :, :dim] = p
            trajectories[i, :, dim:] = q

        time_drvt = Func(torch.cat((p, q), 1))
        dpdt = time_drvt[:, :dim]
        dqdt = time_drvt[:, dim:]

        p_next = p + dpdt * dt
        q_next = q + dqdt * dt

        p = p_next
        q = q_next

    return trajectories


def numerically_integrate(integrator, p_0, q_0, model, method, T, dt, volatile, device, coarsening_factor=1):
    if (coarsening_factor > 1):
        fine_trajectory = numerically_integrate(integrator, p_0, q_0, model, method, T * coarsening_factor,
                                                dt / coarsening_factor, volatile, device)
        trajectory_simulated = fine_trajectory[np.arange(T) * coarsening_factor, :, :]
        return trajectory_simulated
    if (method == 5):
        if (integrator == 'leapfrog'):
            trajectory_simulated = leapfrog(p_0, q_0, model, T, dt, volatile=volatile, device=device)
        elif (integrator == 'euler'):
            trajectory_simulated = euler(p_0, q_0, model, T, dt, volatile=volatile, device=device)
    elif (method == 1):
        if (integrator == 'leapfrog'):
            trajectory_simulated = leapfrog(p_0, q_0, model, T, dt, volatile=volatile, is_Hamilt=False, device=device)
        elif (integrator == 'euler'):
            trajectory_simulated = euler(p_0, q_0, model, T, dt, volatile=volatile, is_Hamilt=False, device=device)
    else:
        trajectory_simulated = model(torch.cat([p_0, q_0], dim=1), T)
    return trajectory_simulated


class MLP1H(nn.Module):
    def __init__(self, n_input, n_hidden, n_output):
        super(MLP1H, self).__init__()
        self.i2h = nn.Linear(n_input, n_hidden)
        self.h2o = nn.Linear(n_hidden, n_output)

    def forward(self, x_input):
        hidden_pre = self.i2h(x_input)
        hidden = hidden_pre.tanh_()
        x_output = self.h2o(hidden)
        return x_output


class MLP2H(nn.Module):
    def __init__(self, n_input, n_hidden, n_output):
        super(MLP2H, self).__init__()
        self.i2h = nn.Linear(n_input, n_hidden)
        self.h2hB = nn.Linear(n_hidden, n_hidden)
        self.h2o = nn.Linear(n_hidden, n_output)

    def forward(self, x_input):
        hidden_pre = self.i2h(x_input)
        hidden = hidden_pre.tanh_()
        hidden_B_pre = self.h2hB(hidden)
        hidden_B = hidden_B_pre.tanh_()
        x_output = self.h2o(hidden_B)
        return x_output

class MLP3H(nn.Module):
    def __init__(self, n_input, n_hidden, n_output):
        super(MLP3H, self).__init__()
        self.i2hA = nn.Linear(n_input, n_hidden)
        self.hA2hB = nn.Linear(n_hidden, n_hidden)
        self.hB2hC = nn.Linear(n_hidden, n_hidden)
        self.hC2o = nn.Linear(n_hidden, n_output)

    def forward(self, x_input):
        hidden_A = self.i2hA(x_input).tanh_()
        hidden_B = self.hA2hB(hidden_A).tanh_()
        hidden_C = self.hB2hC(hidden_B).tanh_()
        x_output = self.hC2o(hidden_C)
        return x_output


class RNN(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(RNN, self).__init__()
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.output_size = output_size

        self.i2h = nn.Linear(input_size, hidden_size)
        self.h2h = nn.Linear(hidden_size, hidden_size)
        self.h2o = nn.Linear(hidden_size, output_size)

    def forward(self, x_0, T, volatile=True):
        batch_size = x_0.shape[0]
        trajectories = torch.empty((T, batch_size, self.output_size), requires_grad=not volatile).to(
            next(self.parameters()).device)
        hidden_init = torch.empty(batch_size, self.hidden_size, requires_grad=not volatile).to(
            next(self.parameters()).device)

        trajectories[0, :, :] = x_0
        x_input = x_0
        hidden = hidden_init
        for t in range(T - 1):
            x_output, hidden = self.forward_step(x_input, hidden)
            trajectories[t + 1, :, :] = x_output
            x_input = x_output
        return trajectories

    def forward_step(self, x_input, hidden):
        hidden_pre = self.i2h(x_input) + self.h2h(hidden)
        hidden = hidden_pre.tanh_()
        x_output = self.h2o(hidden)
        return x_output, hidden

class LSTM(nn.Module):
    def __init__(self, input_size, hco_size):
        super(LSTM, self).__init__()
        self.input_size = input_size
        self.hco_size = hco_size

        self.i2gf = nn.Linear(input_size, hco_size)
        self.i2gi = nn.Linear(input_size, hco_size)
        self.i2go = nn.Linear(input_size, hco_size)
        self.i2cp = nn.Linear(input_size, hco_size)
        self.h2gf = nn.Linear(hco_size, hco_size)
        self.h2gi = nn.Linear(hco_size, hco_size)
        self.h2go = nn.Linear(hco_size, hco_size)
        self.h2cp = nn.Linear(hco_size, hco_size)

    def forward(self, x_0, T, volatile=True):
        batch_size = x_0.shape[0]
        trajectory_predicted = torch.zeros(T, batch_size, self.hco_size, requires_grad=not volatile).to(
            next(self.parameters()).device)
        hidden_init = torch.zeros(batch_size, self.hco_size, requires_grad=not volatile).to(
            next(self.parameters()).device)
        cell_init = torch.zeros(batch_size, self.hco_size, requires_grad=not volatile).to(
            next(self.parameters()).device)

        trajectory_predicted[0, :, :] = x_0
        x_input = x_0
        hidden = hidden_init
        cell = cell_init

        for t in range(T - 1):
            cell, hidden = self.forward_step(x_input, hidden, cell)
            trajectory_predicted[t + 1, :, :] = hidden
            x_input = hidden

        return trajectory_predicted

    def forward_step(self, x_input, hidden, cell):
        gate_f = (self.h2gf(hidden) + self.i2gf(x_input)).sigmoid_()  # size: same as hidden/cell/output
        gate_i = (self.h2gi(hidden) + self.i2gi(x_input)).sigmoid_()  # size: same as hco
        cell_pre = (self.h2cp(hidden) + self.i2cp(x_input)).tanh_()  # size: same as hco
        cell = gate_f * cell + gate_i * cell_pre  # size: same as hco
        gate_o = (self.h2go(hidden) + self.i2go(x_input)).sigmoid_()  # size: same as hco
        hidden = gate_o * cell.tanh_()

        return cell, hidden



