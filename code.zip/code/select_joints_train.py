from __future__ import print_function, absolute_import, division
import yaml
import h5py
import os
import time
import torch
import torch.nn as nn
from torch import optim
from torch.utils.data import DataLoader
from torch.autograd import Variable
import numpy as np
from torch.utils.data.dataloader import DataLoader
import data_utils
import space_angle_velocity
import bone_length_loss
import model_4GRU
import torchsnooper
import matplotlib.pyplot as plt
import scipy.io as io

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
config = yaml.load(open('config.yml'), Loader=yaml.FullLoader)

node_num = config['node_num']
input_n = config['input_n']
output_n = config['output_n']

base_path = '-----------------/data'
input_size = config['in_features']
hidden_size = config['hidden_size']
output_size = config['out_features']
lr = config['learning_rate']
batch_size = config['batch_size']
nodes_num = config['nodes_num']
train_save_path = os.path.join(base_path, 'train.npy')
train_save_path = train_save_path.replace("\\", "/")
dataset = np.load(train_save_path, allow_pickle=True)

# 25node
chain = [[1], [132.95, 442.89, 454.21, 162.77, 75], [132.95, 442.89, 454.21, 162.77, 75],
         [233.58, 257.08, 121.13, 115], [257.08, 151.03, 278.88, 251.73, 100],
         [257.08, 151.03, 278.88, 251.73, 100]]
for x in chain:
    s = sum(x)
    if s == 0:
        continue
    for i in range(len(x)):
        x[i] = (i + 1) * sum(x[i:]) / s

chain = [item for sublist in chain for item in sublist]
nodes_weight = torch.tensor(chain)
nodes_weight = nodes_weight.unsqueeze(1)
nodes_frame_weight = nodes_weight.expand(25, 25)
frame_weight = torch.tensor([3, 2, 1.5, 1.5, 1, 0.5, 0.2, 0.2, 0.1, 0.1,
                             0.06, 0.06, 0.05, 0.05, 0.04, 0.04, 0.03, 0.03, 0.03, 0.02, 0.02,
                             0.02, 0.02, 0.02, 0.02])

"""In every frame, the loss of each joints consists of loss_v,loss_x,loss_y and loss_z"""
dataset_loss = torch.zeros((25))

for i in range(dataset.shape[0]):  # dataset.shape[0]
    print("dataset:", i)
    data = dataset[i]

    train_data = data_utils.LPDataset(data, input_n, output_n)
    train_loader = DataLoader(
        dataset=train_data,
        batch_size=config['batch_size'],
        shuffle=True,
        pin_memory=True,
        drop_last=True
    )

    model_x = model_4GRU.Generator(input_size, hidden_size, output_size, node_num, batch_size)
    model_y = model_4GRU.Generator(input_size, hidden_size, output_size, node_num, batch_size)
    model_z = model_4GRU.Generator(input_size, hidden_size, output_size, node_num, batch_size)
    model_v = model_4GRU.Generator(input_size, hidden_size, output_size, node_num, batch_size)

    mse = nn.MSELoss(reduction='mean')  # --------
    print(">>> total params: {:.2f}M".format(sum(p.numel() for p in model_v.parameters()) / 1000000.0))

    optimizer_x = optim.Adam(model_x.parameters(), lr)
    optimizer_y = optim.Adam(model_y.parameters(), lr)
    optimizer_z = optim.Adam(model_z.parameters(), lr)
    optimizer_v = optim.Adam(model_v.parameters(), lr)


    model_x = torch.load(os.path.join(base_path, 'generator_x_4GRU.pkl'))
    model_y = torch.load(os.path.join(base_path, 'generator_y_4GRU.pkl'))
    model_z = torch.load(os.path.join(base_path, 'generator_z_4GRU.pkl'))
    model_v = torch.load(os.path.join(base_path, 'generator_v_4GRU.pkl'))

    for i, data in enumerate(train_loader):
        print("data: :", i)

        optimizer_x.zero_grad()
        optimizer_y.zero_grad()
        optimizer_z.zero_grad()
        optimizer_v.zero_grad()

        in_shots, out_shot = data
        input_angle = in_shots[:, 1:, :, :3]
        input_velocity = in_shots[:, 1:, :, 3].permute(0, 2, 1)
        target_angle = out_shot[:, :, :, :3]
        target_velocity = out_shot[:, :, :, 3]

        # read velocity
        input_velocity = input_velocity.float()
        target_velocity = target_velocity.float()

        # read angle_x
        input_angle_x = input_angle[:, :, :, 0].permute(0, 2, 1).float()
        target_angle_x = target_angle[:, :, :, 0].float()

        # read angle_y
        input_angle_y = input_angle[:, :, :, 1].permute(0, 2, 1).float()
        target_angle_y = target_angle[:, :, :, 1].float()

        # read angle_z
        input_angle_z = input_angle[:, :, :, 2].permute(0, 2, 1).float()
        target_angle_z = target_angle[:, :, :, 2].float()

        # read 3D data
        input_3d_data = in_shots[:, :, :, 4:]
        target_3d_data = out_shot[:, :, :, 4:]

        loss_v = 0
        loss_x = 0
        loss_y = 0
        loss_z = 0

        output_v = model_v(input_velocity, hidden_size)
        output_v = output_v.view(target_velocity.shape[0], target_velocity.shape[2], output_size)
        # (batch_size,nodes,frame)
        target_velocity_loss = target_velocity.permute(0, 2, 1)
        v = (output_v - target_velocity_loss) * frame_weight * nodes_frame_weight
        loss_v += torch.mean(torch.norm(v, 2, 1))
        dataset_loss += torch.sum(torch.norm(v, 2, 2) ,dim=0)

        output_x = model_x(input_angle_x, hidden_size)
        output_x = output_x.view(target_angle_x.shape[0], target_angle_x.shape[2], output_size)
        target_angle_x_loss = target_angle_x.permute(0, 2, 1)
        x = (output_x - target_angle_x_loss) * frame_weight * nodes_frame_weight
        loss_x += torch.mean(torch.norm(x, 2, 1))
        dataset_loss += torch.sum(torch.norm(x, 2, 2), dim=0)

        output_y = model_y(input_angle_y, hidden_size)
        output_y = output_y.view(target_angle_y.shape[0], target_angle_y.shape[2], output_size)
        target_angle_y_loss = target_angle_y.permute(0, 2, 1)
        y = (output_y - target_angle_y_loss) * frame_weight * nodes_frame_weight
        loss_y += torch.mean(torch.norm(y, 2, 1))
        dataset_loss += torch.sum(torch.norm(y, 2, 2), dim=0)

        output_z = model_z(input_angle_z, hidden_size)
        output_z = output_z.view(target_angle_z.shape[0], target_angle_z.shape[2], output_size)
        target_angle_z_loss = target_angle_z.permute(0, 2, 1)
        z = (output_z - target_angle_z_loss) * frame_weight * nodes_frame_weight
        loss_z += torch.mean(torch.norm(z, 2, 1))
        dataset_loss += torch.sum(torch.norm(z, 2, 2), dim=0)

        angle_x = output_x.permute(0, 2, 1)
        angle_y = output_y.permute(0, 2, 1)
        angle_z = output_z.permute(0, 2, 1)
        pred_v = output_v.permute(0, 2, 1)

        pred_angle_set = torch.stack((angle_x, angle_y, angle_z), 3)
        pred_angle_set = pred_angle_set.reshape(pred_angle_set.shape[0], pred_angle_set.shape[1], -1, 3)

        total_loss = loss_v + loss_x + loss_y + loss_z
        total_loss.backward()

        nn.utils.clip_grad_norm_(model_x.parameters(), config['gradient_clip'])
        nn.utils.clip_grad_norm_(model_y.parameters(), config['gradient_clip'])
        nn.utils.clip_grad_norm_(model_z.parameters(), config['gradient_clip'])
        nn.utils.clip_grad_norm_(model_v.parameters(), config['gradient_clip'])

        optimizer_x.step()
        optimizer_y.step()
        optimizer_z.step()
        optimizer_v.step()

move_joint = np.array([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 13, 14, 15, 17, 18, 19, 21, 22, 25, 26, 27, 29, 30])
move_joint_list = move_joint.tolist()
dataset_loss = dataset_loss.detach().numpy().tolist()


idx_zip = zip(dataset_loss,move_joint_list)
sorted_idx = sorted(idx_zip, reverse=True)

for i in range(25):
    print(sorted_idx[i][0])

res = []
for i in range(25):
    res.append(sorted_idx[i][1])
print(res)
final_res = res[0:nodes_num]
print(final_res)

f = open("k.txt", "w")
for line in final_res:
    f.write(str(line) + '\n')
f.close()


