from __future__ import print_function, absolute_import, division
import yaml
import h5py
import os
import time
import torch
import torch.nn as nn
from torch import optim
from torch.utils.data import DataLoader
from torch.autograd import Variable
import numpy as np
from torch.utils.data.dataloader import DataLoader
import data_utils
import space_angle_velocity
import bone_length_loss
import model_enhance_each_joint
import model_TCN_enhance
import torchsnooper
import matplotlib.pyplot as plt
import scipy.io as io
import ctypes
import time
# ctypes.cdll.LoadLibrary('caffe2_nvrtc.dll')


device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
config = yaml.load(open('config.yml'), Loader=yaml.FullLoader)

node_num = config['node_num']
input_n = config['input_n']
output_n = config['output_n']
# path_to_data = 'D:/motion_prediction_data/motion_prediction_control_experiment/h36m_3d_txt/right_3D_txt'
base_path = 'F:\研究方向总结\A 我的小论文\在投\PAMI code\code 25\Para'
input_size = 25
hidden_size = config['hidden_size']
output_size = config['out_features']
lr = config['learning_rate']
batch_size = config['batch_size']
enhance_num = config['enhance_num']
train_save_path = os.path.join(base_path, 'train.npy')
train_save_path = train_save_path.replace("\\", "/")
dataset = np.load(train_save_path, allow_pickle=True)

move_joint = np.array([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 13, 14, 15, 17, 18, 19, 21, 22, 25, 26, 27, 29, 30])
use_node = np.array([0, 1, 2, 3, 6, 7, 8, 11, 12, 13, 14, 15, 16, 17, 20, 21, 22])

frame_weight = torch.tensor([3, 2, 1.5, 1.5, 1, 0.5, 0.2, 0.2, 0.1, 0.1,
                             0.06, 0.06, 0.05, 0.05, 0.04, 0.04, 0.03, 0.03, 0.03, 0.02, 0.02,
                             0.02, 0.02, 0.02, 0.02])

frame_weight = frame_weight.to(device)

time_start = time.time()  # 记录开始时间
for k in use_node:

    model_generator_x = torch.load(os.path.join(base_path, 'generator_x_' + str(move_joint[k]) + ".pkl")).to(device)
    model_generator_y = torch.load(os.path.join(base_path, 'generator_y_' + str(move_joint[k]) + ".pkl")).to(device)
    model_generator_z = torch.load(os.path.join(base_path, 'generator_z_' + str(move_joint[k]) + ".pkl")).to(device)
    model_generator_v = torch.load(os.path.join(base_path, 'generator_v_' + str(move_joint[k]) + ".pkl")).to(device)

    model_x = model_TCN_enhance.TCN(1, [1, 1, 1, 1, 1], kernel_size=3, dropout=0.1, block_num=3, output_n=25)
    model_y = model_TCN_enhance.TCN(1, [1, 1, 1, 1, 1], kernel_size=3, dropout=0.1, block_num=3, output_n=25)
    model_z = model_TCN_enhance.TCN(1, [1, 1, 1, 1, 1], kernel_size=3, dropout=0.1, block_num=3, output_n=25)
    model_v = model_TCN_enhance.TCN(1, [1, 1, 1, 1, 1], kernel_size=3, dropout=0.1, block_num=3, output_n=25)

    mse = nn.MSELoss(reduction='mean')  # 均方损失函数
    print(">>> total params: {:.2f}M".format(sum(p.numel() for p in model_v.parameters()) / 1000000.0))

    optimizer_x = optim.Adam(model_x.parameters(), lr)
    optimizer_y = optim.Adam(model_y.parameters(), lr)
    optimizer_z = optim.Adam(model_z.parameters(), lr)
    optimizer_v = optim.Adam(model_v.parameters(), lr)

    scheduler_x = torch.optim.lr_scheduler.ExponentialLR(optimizer_x, gamma=0.98)
    scheduler_y = torch.optim.lr_scheduler.ExponentialLR(optimizer_y, gamma=0.98)
    scheduler_z = torch.optim.lr_scheduler.ExponentialLR(optimizer_z, gamma=0.98)
    scheduler_v = torch.optim.lr_scheduler.ExponentialLR(optimizer_v, gamma=0.98)

    for epoch in range(5):

        for i in range(dataset.shape[0]):  # dataset.shape[0]
            data = dataset[i]

            train_data = data_utils.LPDataset(data, input_n, output_n)
            train_loader = DataLoader(
                dataset=train_data,
                batch_size=config['batch_size'],
                shuffle=True,
                pin_memory=True,
                drop_last=True
            )

            base_name = "generator_x_enhance_" + str(move_joint[k]) + ".pkl"
            if os.path.exists(os.path.join(base_path, base_name)):

                model_x.load_state_dict(torch.load(os.path.join(base_path, 'generator_x_enhance_' + str(move_joint[k]) + ".pkl")), strict=False)
                model_y.load_state_dict(torch.load(os.path.join(base_path, 'generator_y_enhance_' + str(move_joint[k]) + ".pkl")), strict=False)
                model_z.load_state_dict(torch.load(os.path.join(base_path, 'generator_z_enhance_' + str(move_joint[k]) + ".pkl")), strict=False)

                model_x.to(device)
                model_y.to(device)
                model_z.to(device)

                model_generator_x.to(device)
                model_generator_y.to(device)
                model_generator_z.to(device)
                model_generator_v.to(device)

                for i, data in enumerate(train_loader):
                    # print("---------------Two---------------")
                    optimizer_x.zero_grad()
                    optimizer_y.zero_grad()
                    optimizer_z.zero_grad()
                    optimizer_v.zero_grad()

                    in_shots, out_shot = data
                    in_shots = in_shots.to(device)
                    out_shot = out_shot.to(device)
                    input_angle = in_shots[:, 1:, k, :3].unsqueeze(dim=2)
                    input_velocity = in_shots[:, 1:, k, 3].unsqueeze(dim=2).permute(0, 2, 1)
                    target_angle = out_shot[:, :, k, :3].unsqueeze(dim=2)
                    target_velocity = out_shot[:, :, k, 3].unsqueeze(dim=2)

                    # read velocity
                    input_velocity = input_velocity.float()
                    target_velocity = target_velocity.float()

                    # read angle_x
                    input_angle_x = input_angle[:, :, :, 0].permute(0, 2, 1).float()
                    target_angle_x = target_angle[:, :, :, 0].float()

                    # read angle_y
                    input_angle_y = input_angle[:, :, :, 1].permute(0, 2, 1).float()
                    target_angle_y = target_angle[:, :, :, 1].float()

                    # read angle_z
                    input_angle_z = input_angle[:, :, :, 2].permute(0, 2, 1).float()
                    target_angle_z = target_angle[:, :, :, 2].float()

                    # read 3D data note:here, the data is about enhance model
                    input_3d_data = in_shots[:, :, k, 4:].unsqueeze(dim=2)
                    target_3d_data = out_shot[:, :, k, 4:].unsqueeze(dim=2)

                    enhance_input_v = model_generator_v(input_velocity).detach()
                    enhance_input_x = model_generator_x(input_angle_x).detach()
                    enhance_input_y = model_generator_y(input_angle_y).detach()
                    enhance_input_z = model_generator_z(input_angle_z).detach()

                    angle_x = enhance_input_x.permute(0, 2, 1)
                    angle_y = enhance_input_y.permute(0, 2, 1)
                    angle_z = enhance_input_z.permute(0, 2, 1)
                    pred_v = enhance_input_v.permute(0, 2, 1)

                    pred_angle_set = torch.stack((angle_x, angle_y, angle_z), 3)
                    pred_angle_set = pred_angle_set.reshape(pred_angle_set.shape[0], pred_angle_set.shape[1], -1, 3)

                    # reconstruction
                    input_pose = torch.zeros(
                        (target_velocity.shape[0], output_n, input_3d_data.shape[-2], input_3d_data.shape[-1]))

                    for a in range(input_pose.shape[0]):
                        input_pose[a, 0, :, :] = input_3d_data[a, -1, :, :]

                    re_data = torch.FloatTensor([]).to(device)
                    re_data.requires_grad_(True)
                    for b in range(target_3d_data.shape[0]):
                        for c in range(target_3d_data.shape[1]):
                            reconstruction_coordinate = space_angle_velocity.reconstruction_motion(pred_v[b, c, :, ],
                                                                                                   pred_angle_set[b, c,
                                                                                                   :, :],
                                                                                                   input_pose[b, c, :,
                                                                                                   :], 1)
                            reconstruction_coordinate = reconstruction_coordinate.to(device)
                            re_data = torch.cat([re_data, reconstruction_coordinate], dim=0)
                            if c + 1 < target_3d_data.shape[1]:
                                input_pose[b, c + 1, :, :] = reconstruction_coordinate
                            else:
                                continue

                    re_data = re_data.view(target_3d_data.shape[0], -1, 1, 3)

                    input_x = re_data[:, :, :, 0].permute(0, 2, 1).float()
                    target_x = target_3d_data[:, :, :, 0].float()

                    input_y = re_data[:, :, :, 1].permute(0, 2, 1).float()
                    target_y = target_3d_data[:, :, :, 1].float()

                    input_z = re_data[:, :, :, 2].permute(0, 2, 1).float()
                    target_z = target_3d_data[:, :, :, 2].float()

                    loss_px = 0
                    loss_py = 0
                    loss_pz = 0

                    output_px = model_x(input_x)
                    output_px = output_px.view(target_x.shape[0], target_x.shape[2], output_size)
                    target_x_loss = target_x.permute(0, 2, 1)
                    loss_px += torch.mean(
                        torch.norm((output_px - target_x_loss) * frame_weight, 2, 1))

                    output_py = model_y(input_y)
                    output_py = output_py.view(target_y.shape[0], target_y.shape[2], output_size)
                    target_y_loss = target_y.permute(0, 2, 1)
                    loss_py += torch.mean(
                        torch.norm((output_py - target_y_loss) * frame_weight, 2, 1))

                    output_pz = model_z(input_z)
                    output_pz = output_pz.view(target_z.shape[0], target_z.shape[2], output_size)
                    target_z_loss = target_z.permute(0, 2, 1)
                    loss_pz += torch.mean(
                        torch.norm((output_pz - target_z_loss) * frame_weight, 2, 1))

                    loss_px.backward()
                    loss_py.backward()
                    loss_pz.backward()
                    nn.utils.clip_grad_norm_(model_x.parameters(), config['gradient_clip'])
                    nn.utils.clip_grad_norm_(model_y.parameters(), config['gradient_clip'])
                    nn.utils.clip_grad_norm_(model_z.parameters(), config['gradient_clip'])

                    optimizer_x.step()
                    optimizer_y.step()
                    optimizer_z.step()
                    print('[epoch %d] [step %d] [loss_px %.4f] [loss_py %.4f] [loss_pz %.4f]'
                          % (epoch, i, loss_px.item(), loss_py.item(), loss_pz.item()))

                torch.save(model_x.state_dict(), os.path.join(base_path, 'generator_x_enhance_' + str(move_joint[k]) + ".pkl"))
                torch.save(model_y.state_dict(), os.path.join(base_path, 'generator_y_enhance_' + str(move_joint[k]) + ".pkl"))
                torch.save(model_z.state_dict(), os.path.join(base_path, 'generator_z_enhance_' + str(move_joint[k]) + ".pkl"))

            else:

                model_x.to(device)
                model_y.to(device)
                model_z.to(device)

                model_generator_x.to(device)
                model_generator_y.to(device)
                model_generator_z.to(device)
                model_generator_v.to(device)

                for i, data in enumerate(train_loader):
                    # print("---------------Two---------------")
                    optimizer_x.zero_grad()
                    optimizer_y.zero_grad()
                    optimizer_z.zero_grad()
                    optimizer_v.zero_grad()

                    in_shots, out_shot = data
                    in_shots = in_shots.to(device)
                    out_shot = out_shot.to(device)
                    input_angle = in_shots[:, 1:, k, :3].unsqueeze(dim=2)
                    input_velocity = in_shots[:, 1:, k, 3].unsqueeze(dim=2).permute(0, 2, 1)
                    target_angle = out_shot[:, :, k, :3].unsqueeze(dim=2)
                    target_velocity = out_shot[:, :, k, 3].unsqueeze(dim=2)

                    # read velocity
                    input_velocity = input_velocity.float()
                    target_velocity = target_velocity.float()

                    # read angle_x
                    input_angle_x = input_angle[:, :, :, 0].permute(0, 2, 1).float()
                    target_angle_x = target_angle[:, :, :, 0].float()

                    # read angle_y
                    input_angle_y = input_angle[:, :, :, 1].permute(0, 2, 1).float()
                    target_angle_y = target_angle[:, :, :, 1].float()

                    # read angle_z
                    input_angle_z = input_angle[:, :, :, 2].permute(0, 2, 1).float()
                    target_angle_z = target_angle[:, :, :, 2].float()

                    # read 3D data note:here, the data is about enhance model
                    input_3d_data = in_shots[:, :, k, 4:].unsqueeze(dim=2)
                    target_3d_data = out_shot[:, :, k, 4:].unsqueeze(dim=2)

                    enhance_input_v = model_generator_v(input_velocity).detach()
                    enhance_input_x = model_generator_x(input_angle_x).detach()
                    enhance_input_y = model_generator_y(input_angle_y).detach()
                    enhance_input_z = model_generator_z(input_angle_z).detach()

                    angle_x = enhance_input_x.permute(0, 2, 1)
                    angle_y = enhance_input_y.permute(0, 2, 1)
                    angle_z = enhance_input_z.permute(0, 2, 1)
                    pred_v = enhance_input_v.permute(0, 2, 1)

                    pred_angle_set = torch.stack((angle_x, angle_y, angle_z), 3)
                    pred_angle_set = pred_angle_set.reshape(pred_angle_set.shape[0], pred_angle_set.shape[1], -1, 3)

                    # reconstruction
                    input_pose = torch.zeros(
                        (target_velocity.shape[0], output_n, input_3d_data.shape[-2], input_3d_data.shape[-1]))

                    for a in range(input_pose.shape[0]):
                        input_pose[a, 0, :, :] = input_3d_data[a, -1, :, :]

                    re_data = torch.FloatTensor([]).to(device)
                    re_data.requires_grad_(True)
                    for b in range(target_3d_data.shape[0]):
                        for c in range(target_3d_data.shape[1]):
                            reconstruction_coordinate = space_angle_velocity.reconstruction_motion(pred_v[b, c, :, ],
                                                                                                   pred_angle_set[b, c,
                                                                                                   :, :],
                                                                                                   input_pose[b, c, :,
                                                                                                   :], 1)
                            reconstruction_coordinate = reconstruction_coordinate.to(device)
                            re_data = torch.cat([re_data, reconstruction_coordinate], dim=0)
                            if c + 1 < target_3d_data.shape[1]:
                                input_pose[b, c + 1, :, :] = reconstruction_coordinate
                            else:
                                continue

                    re_data = re_data.view(target_3d_data.shape[0], -1, 1, 3)

                    input_x = re_data[:, :, :, 0].permute(0, 2, 1).float()
                    target_x = target_3d_data[:, :, :, 0].float()

                    input_y = re_data[:, :, :, 1].permute(0, 2, 1).float()
                    target_y = target_3d_data[:, :, :, 1].float()

                    input_z = re_data[:, :, :, 2].permute(0, 2, 1).float()
                    target_z = target_3d_data[:, :, :, 2].float()

                    loss_px = 0
                    loss_py = 0
                    loss_pz = 0
                    # print("input_size:", np.shape(input_x))
                    output_px = model_x(input_x)
                    output_px = output_px.view(target_x.shape[0], target_x.shape[2], output_size)
                    target_x_loss = target_x.permute(0, 2, 1)
                    loss_px += torch.mean(
                        torch.norm((output_px - target_x_loss) * frame_weight, 2, 1))

                    output_py = model_y(input_y)
                    output_py = output_py.view(target_y.shape[0], target_y.shape[2], output_size)
                    target_y_loss = target_y.permute(0, 2, 1)
                    loss_py += torch.mean(
                        torch.norm((output_py - target_y_loss) * frame_weight, 2, 1))

                    output_pz = model_z(input_z)
                    output_pz = output_pz.view(target_z.shape[0], target_z.shape[2], output_size)
                    target_z_loss = target_z.permute(0, 2, 1)
                    loss_pz += torch.mean(
                        torch.norm((output_pz - target_z_loss) * frame_weight, 2, 1))

                    loss_px.backward()
                    loss_py.backward()
                    loss_pz.backward()
                    nn.utils.clip_grad_norm_(model_x.parameters(), config['gradient_clip'])
                    nn.utils.clip_grad_norm_(model_y.parameters(), config['gradient_clip'])
                    nn.utils.clip_grad_norm_(model_z.parameters(), config['gradient_clip'])

                    optimizer_x.step()
                    optimizer_y.step()
                    optimizer_z.step()
                    print('[epoch %d] [step %d] [loss_px %.4f] [loss_py %.4f] [loss_pz %.4f]'
                          % (epoch, i, loss_px.item(), loss_py.item(), loss_pz.item()))

                torch.save(model_x.state_dict(),
                           os.path.join(base_path, 'generator_x_enhance_' + str(move_joint[k]) + ".pkl"))
                torch.save(model_y.state_dict(),
                           os.path.join(base_path, 'generator_y_enhance_' + str(move_joint[k]) + ".pkl"))
                torch.save(model_z.state_dict(),
                           os.path.join(base_path, 'generator_z_enhance_' + str(move_joint[k]) + ".pkl"))

        scheduler_x.step()
        scheduler_y.step()
        scheduler_z.step()

    torch.save(model_x, os.path.join(base_path, 'generator_x_enhance_' + str(move_joint[k]) + ".pkl"))
    torch.save(model_y, os.path.join(base_path, 'generator_y_enhance_' + str(move_joint[k]) + ".pkl"))
    torch.save(model_z, os.path.join(base_path, 'generator_z_enhance_' + str(move_joint[k]) + ".pkl"))

time_end = time.time()
time_sum = time_end - time_start
print(time_sum)