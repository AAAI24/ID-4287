import torch.nn as nn
import torch
from torch.nn.parameter import Parameter
import math
import torch.nn.functional as F
from max_sv import max_singular_value
from model_GAT import GAT



class Graph():
    def __init__(self):
        self.get_edge()

    def get_edge(self):
        self.node_num = 25
        self_link = [(i, i) for i in range(self.node_num)]
        bone_link = [(0, 1), (1, 2), (2, 3), (3, 4), (4, 5), (0, 6), (6, 7), (7, 8), (8, 9), (9, 10), (0, 11),
                     (11, 12), (12, 13), (13, 14), (12, 15), (15, 16), (16, 17), (17, 19),
                     (17, 18), (12, 20), (20, 21), (21, 22), (22, 23), (22, 24)]
        self.edge = self_link + bone_link

        self.pre_sem_edge = [(2, 7), (3, 8), (16, 21), (17, 22)]
        A_ske = torch.zeros((self.node_num, self.node_num))
        for i, j in self.edge:
            A_ske[j, i] = 1
            A_ske[i, j] = 1
        self.A_ske = A_ske
        A_pre_sem = torch.zeros((self.node_num, self.node_num))
        for p, q in self.pre_sem_edge:
            A_pre_sem[p, q] = 1
            A_pre_sem[q, p] = 1
        self.A_pre_sem = A_pre_sem

        return A_ske, A_pre_sem


class SemskeConv(nn.Module):

    def __init__(self, in_features, out_features, node_num, bias=True):
        super(SemskeConv, self).__init__()
        self.node_num = node_num

        self.graph = Graph()

        A_ske = torch.tensor(self.graph.A_ske, dtype=torch.float, requires_grad=False)
        A_pre_sem = torch.tensor(self.graph.A_pre_sem, dtype=torch.float, requires_grad=False)
        A_sem = nn.Parameter(torch.zeros(node_num, node_num))
        adj = A_ske + A_pre_sem + A_sem
        self.adj = adj

        self.M = nn.Parameter(torch.zeros(node_num, node_num))
        self.W = nn.Parameter(torch.zeros(node_num, node_num))

        if bias:
            self.bias = nn.Parameter(torch.FloatTensor(node_num))
            stdv = 1. / math.sqrt(self.M.size(1))
            self.bias.data.uniform_(-stdv, stdv)

        else:
            self.register_parameter('bias', None)

    def forward(self, input):

        self.adj = nn.Parameter(torch.where(torch.isnan(self.adj), torch.full_like(self.adj, 0), self.adj))
        self.W = nn.Parameter(torch.where(torch.isnan(self.W), torch.full_like(self.W, 0), self.W))
        self.M = nn.Parameter(torch.where(torch.isnan(self.M), torch.full_like(self.M, 0), self.M))

        Adj = 0.50 * (self.adj + self.adj.permute(1, 0))  # permute(1, 0)
        Adj_W = torch.mul(Adj, self.W)
        support = torch.matmul(input, Adj_W)    #
        output = torch.matmul(support, self.M)

        if self.bias is not None:
            return output + self.bias
        else:
            return output


class _GraphConv(nn.Module):
    def __init__(self, in_features, hidden_feature, node_num, p_dropout=0.005):
        super(_GraphConv, self).__init__()

        self.gconv1 = SemskeConv(in_features, hidden_feature, node_num)
        self.bn = nn.BatchNorm1d(node_num * hidden_feature)
        self.gconv2 = SemskeConv(hidden_feature, in_features, node_num)

        self.tanh = nn.Tanh()

        if p_dropout is not None:
            self.dropout = nn.Dropout(p_dropout)
        else:
            self.dropout = None

    def forward(self, x):
        y = self.gconv1(x)
        # print('y:\n',y.shape)
        b, f, n = y.shape
        y = self.bn(y.view(b, -1)).view(b, f, n)
        y = self.tanh(y)
        if self.dropout is not None:
            y = self.dropout(y)
        y = self.gconv2(y)
        b, f, n = y.shape
        y = self.bn(y.view(b, -1)).view(b, f, n)
        y = self.tanh(y)
        y = y + x

        return y

# SparseAttention + GRU
# class Generator(nn.Module):
#
#     def __init__(self, input_size, hidden_size, output_size, node_num, batch_size):
#         super(Generator, self).__init__()
#
#         self.hidden_prev = nn.Parameter(torch.zeros(1, batch_size, hidden_size))
#
#         self.GRU = nn.GRU(input_size=input_size, hidden_size=hidden_size,
#                           num_layers=1, dropout=0.05, batch_first=True)
#         self.GCN = _GraphConv(1, 9, node_num)
#
#         self.linear = nn.Linear(hidden_size, output_size)  # 
#
#         self.SparseAttention = GAT(input_size, output_size, input_size, dropout=0.1, alpha=0.2, nheads=1)
#
#         self_link = [(i, i) for i in range(node_num)]
#         bone_link = [(0, 1), (1, 2), (2, 3), (3, 4), (4, 5), (0, 6), (6, 7), (7, 8), (8, 9), (9, 10), (0, 11),
#                      (11, 12), (12, 13), (13, 14), (12, 15), (15, 16), (16, 17), (17, 19),
#                      (17, 18), (12, 20), (20, 21), (21, 22), (22, 23), (22, 24)]
#         self.edge = self_link + bone_link
#
#         A_ske = torch.zeros((node_num, node_num))
#         for i, j in self.edge:
#             A_ske[j, i] = 1
#             A_ske[i, j] = 1
#         self.adj = A_ske
#
#     def forward(self, x, hidden_size):
#         # GCN block
#         # print("1: ",x.shape) # torch.Size([16, 25, 9])
#         # x = x.permute(0, 2, 1)
#         # print("2: ",x.shape) # torch.Size([16, 9, 25])
#         #
#         # exit()
#         '''
#         GCN_set = torch.tensor([])
#         for i in range (x.shape[1]):
#             q = self.GCN(x[:,i,:])
#             GCN_set = torch.cat((GCN_set,q))
#         '''
#
#         # GCN_set = self.GCN(x)
#         # print("GCN_set: ",GCN_set.size())  # torch.Size([16, 9, 25])
#         # x = GCN_set.reshape(x.shape[0], x.shape[1], x.shape[2])
#         # print("4: ",x.shape) # torch.Size([16, 9, 25])
#
#         # x = x.permute(0, 2, 1)
#         x = self.SparseAttention(x, self.adj)
#         # x = x.permute(0, 2, 1)
#         # print("5: ",x.shape) # torch.Size([16, 25, 9])
#
#         out, h = self.GRU(x, self.hidden_prev)
#         # print("6: ",out.size()) # torch.Size([16, 25, 128])
#         out = out.reshape(-1, hidden_size)
#         # print("7: ",out.size()) # torch.Size([400, 128])
#         out = self.linear(out)
#         # print("8: ",out.size()) # torch.Size([400, 25])
#         out = out.unsqueeze(dim=0)
#         # print("9: ",out.size()) # torch.Size([1, 400, 25])
#         return out


# 　origin GCN+GRU
class Generator(nn.Module):

    def __init__(self, input_size, hidden_size, output_size, node_num, batch_size):

        super(Generator, self).__init__()
        self.hidden_prev = nn.Parameter(torch.zeros(1, batch_size, hidden_size))
        self.GRU = nn.GRU(input_size=input_size, hidden_size=hidden_size,
                          num_layers=1, dropout=0.05, batch_first=True)
        self.GCN = _GraphConv(1, 9, node_num)
        self.linear = nn.Linear(hidden_size, output_size)  #
    def forward(self, x, hidden_size):
        # GCN block
        # print("1: ",x.shape) # torch.Size([16, 25, 9])
        x = x.permute(0, 2, 1)
        # print("2: ",x.shape) # torch.Size([16, 9, 25])

        '''
        exit()
        GCN_set = torch.tensor([])
        for i in range (x.shape[1]):
            q = self.GCN(x[:,i,:])
            GCN_set = torch.cat((GCN_set,q))
        '''

        GCN_set = self.GCN(x)
        # print("GCN_set: ",GCN_set.size())  # torch.Size([16, 9, 25])
        x = GCN_set.reshape(x.shape[0], x.shape[1], x.shape[2])
        # print("4: ",x.shape) # torch.Size([16, 9, 25])

        x = x.permute(0, 2, 1)
        # print("5: ",x.shape) # torch.Size([16, 25, 9])

        out, h = self.GRU(x, self.hidden_prev)
        # print("6: ",out.size()) # torch.Size([16, 25, 128])
        out = out.reshape(-1, hidden_size)
        # print("7: ",out.size()) # torch.Size([400, 128])
        out = self.linear(out)
        # print("8: ",out.size()) # torch.Size([400, 25])
        out = out.unsqueeze(dim=0)
        # print("9: ",out.size()) # torch.Size([1, 400, 25])
        return out

# pure GRU
# class Generator(nn.Module):
#
#     def __init__(self, input_size, hidden_size, output_size, node_num, batch_size):
#
#         super(Generator, self).__init__()
#         self.hidden_prev = nn.Parameter(torch.zeros(1, batch_size, hidden_size))
#         self.GRU = nn.GRU(input_size=input_size, hidden_size=hidden_size,
#                           num_layers=1, dropout=0.05, batch_first=True)
#         self.linear = nn.Linear(hidden_size, output_size)  # 
#
#     def forward(self, x, hidden_size):
#         out, h = self.GRU(x, self.hidden_prev)
#         out = out.reshape(-1, hidden_size)
#         out = self.linear(out)
#         out = out.unsqueeze(dim=0)
#         # print("9: ",out.size()) # torch.Size([1, batch_size * node_num, 25])
#         return out

# linear
# class Generator(nn.Module):
#
#     def __init__(self, input_size, hidden_size, output_size, node_num, batch_size):
#         super(Generator, self).__init__()
#         half_times = hidden_size // 2
#         self.generator = nn.Sequential(
#             nn.Linear(input_size, hidden_size),
#             nn.ReLU(),
#             nn.Linear(hidden_size, half_times),
#             nn.ReLU(),
#             nn.Linear(half_times, output_size),
#         )
#
#     def forward(self, x, hidden_size):
#         # x is torch.Size([16, 25, 9])
#         x = x.reshape(x.shape[0] * x.shape[1], -1)
#         out = self.generator(x)
#         out = out.unsqueeze(dim=0)
#         return out

# class ResBlock(nn.Module):
#     def __init__(self, in_channels, out_channels, hidden_channels=None, upsample=False):
#         super(ResBlock, self).__init__()
#
#         hidden_channels = in_channels
#         self.upsample = upsample
#         self.conv1 = nn.Conv2d(in_channels, hidden_channels, kernel_size=3, padding=1)
#         self.conv2 = nn.Conv2d(hidden_channels, out_channels, kernel_size=3, padding=1)
#         self.conv_sc = nn.Conv2d(in_channels, out_channels, kernel_size=1, padding=0)
#         self.upsampling = nn.UpsamplingBilinear2d(scale_factor=2)
#         self.bn1 = nn.BatchNorm2d(in_channels)
#         self.bn2 = nn.BatchNorm2d(hidden_channels)
#         self.relu = nn.ReLU()
#
#     def forward_residual_connect(self, input):
#         out = self.conv_sc(input)
#         if self.upsample:
#              out = self.upsampling(out)
#         return out
#
#     def forward(self, input):
#         out = self.relu(self.bn1(input))
#         out = self.conv1(out)
#         if self.upsample:
#              out = self.upsampling(out)
#         out = self.relu(self.bn2(out))
#         out = self.conv2(out)
#         out_res = self.forward_residual_connect(input)
#         # print((out + out_res).size())
#         return out + out_res
#
# class Generator(nn.Module):
#     def __init__(self, input_size, hidden_size, output_size=25, node_num=25, batch_size=16):
#         super(Generator, self).__init__()
#         self.input_layer = nn.Linear(input_size, hidden_size)
#         self.generator = self.make_model()
#
#     def make_model(self):
#         model = []
#         model += [ResBlock(1, 4)]
#         model += [ResBlock(4, 4)]
#         model += [ResBlock(4, 1)]
#         model += [nn.BatchNorm2d(1)]
#         model += [nn.ReLU()]
#         model += [nn.Conv2d(1, 1, kernel_size=3, stride=1, padding=1)]
#         model += [nn.AdaptiveAvgPool2d((5,5))]
#         model += [nn.Tanh()]
#         return nn.Sequential(*model)
#
#     def forward(self, x,hidden_size):
#         # x is torch.Size([16, 25, 9])
#         x = x.reshape(x.shape[0]*x.shape[1],-1) # 400 * 9
#         # z = torch.randn(x.shape[0],x.shape[1])
#
#         out = self.input_layer(x)
#         # print("after layer: ",out.size())
#         out = out.view(x.size(0), 1, 8,8 )
#         # print("after view: ", out.size())
#         out = self.generator(out)
#         # print("after generator: ", out.size())
#         return out


class SNLinear(nn.modules.Linear):
    def __init__(self, in_features, out_features, bias=True):
        super(SNLinear, self).__init__(in_features, out_features, bias)
        self.register_buffer('u', torch.Tensor(1, out_features).normal_())

    @property
    def W_(self):
        w_mat = self.weight.view(self.weight.size(0), -1)
        sigma, _u = max_singular_value(w_mat, self.u)   # sigma 
        self.u.copy_(_u)
        return self.weight / sigma

    def forward(self, input):
        return F.linear(input, self.W_, self.bias)

class Discriminator(nn.Module):
    def __init__(self ):
        super(Discriminator, self).__init__()
        self.dis = nn.Sequential(
            SNLinear(25 * 25, 128),
            nn.ReLU(),
            SNLinear(128, 1),
            nn.Sigmoid()
        )

    def forward(self, x):
        # 16*25*25
        x = x.permute(0, 2, 1)  # batch_size * nodes * frame
        x = x.reshape(x.shape[0], -1)
        x = self.dis(x)
        x = x.reshape(x.shape[0])
        return x